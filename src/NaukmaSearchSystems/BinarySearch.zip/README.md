**Practical task summary**

TotalInputWords: 385967  
TotalDictionaryWords: 11780  

Complexity of adding unique words to dictionary: O(1). HashSet is used thus no traversing dictionary whatsoever  
Complexity of extracting words from character stream: O(1). Parsing is per symbol.  

Memory consumption: not measured