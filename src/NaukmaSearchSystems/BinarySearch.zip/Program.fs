﻿open System.IO
open BinarySearch
open FSharp.Control

open Functions

[<EntryPoint>]
let main _ =        
    let textFilePaths = Directory.GetFiles(Directory.GetCurrentDirectory())
                        |> Array.filter (fun filePath -> FileInfo(filePath).Extension = ".txt") 
                        |> shuffle
    
    Async.RunSynchronously (getDictionaryAsync textFilePaths)
        |> serializeDictionaryToJsonFile
        |> ignore
    
    0